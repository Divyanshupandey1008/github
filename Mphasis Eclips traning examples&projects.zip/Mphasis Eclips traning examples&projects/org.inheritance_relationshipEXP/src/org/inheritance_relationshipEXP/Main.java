package org.inheritance_relationshipEXP;

	public class Main
	{
	public static void main(String[] args) 
	{
	Bank ob=new Bank(1001,5000,"SBI MG Road");
	Customer ob1=new Customer("Sandip","Bangalore",ob);
	ob1.display();
	}
	
	}

