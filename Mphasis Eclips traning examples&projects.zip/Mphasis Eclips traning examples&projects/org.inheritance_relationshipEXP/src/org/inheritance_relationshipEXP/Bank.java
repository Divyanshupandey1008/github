package org.inheritance_relationshipEXP;


public class Bank {
	int accno,balance;
	String branchname;
	public Bank(int accno, int balance, String branchname) {
		super();
		this.accno = accno;
		this.balance = balance;
		this.branchname = branchname;
}
	@Override
	public String toString() {
		return "Bank [accno=" + accno + ", balance=" + balance + ", branchname=" + branchname + "]";
	}

}

