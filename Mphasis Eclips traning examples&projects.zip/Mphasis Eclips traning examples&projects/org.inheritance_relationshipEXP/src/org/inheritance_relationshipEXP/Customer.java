package org.inheritance_relationshipEXP;

public class Customer {
String custname,address;
Bank Bank;

public Customer(String custname, String address, org.inheritance_relationshipEXP.Bank bank) {
	super();
	this.custname = custname;
	this.address = address;
	Bank = bank;
}
void display()
{
	System.out.println("The Customer name is "+custname);
	System.out.println("The Customer address is "+address);
	System.out.println("The Bank details is "+Bank);
		}


}
