package org.FileHandling;
import java.io.*;

public class Serialization_exp {
	public static void main(String[] args)throws IOException 
	{
		Student obj=new Student();
		obj.rollno=101;
		obj.name="sandip";
		obj.address="bangalore";
		FileOutputStream fos=new FileOutputStream("Object.txt");
		ObjectOutputStream os=new ObjectOutputStream(fos);
		os.writeObject(obj);
		fos.close();os.close();
		System.out.println("Object written into the file..................");

}
}