package org.FileHandling;
import java.io.*;
import java.util.*;
public class File_handling_exp1 {
	public static void main(String[] args) 
	{
	Scanner ob=new Scanner(System.in);
	System.out.println("Enter the file name");
	String fname=ob.next();
	File f=new File(fname);
	System.out.println("The file name is "+f.getName());
	System.out.println("The file path is "+f.getPath());
	System.out.println("The file absolute path is "+f.getAbsolutePath());
	System.out.println("The file existing is "+f.exists());
	System.out.println("The file is in read mode "+f.canRead());
	System.out.println("The file is in write mode "+f.canWrite());
	System.out.println("The file is in execute mode "+f.canExecute());
	System.out.println("The file length is "+f.length());
	System.out.println("The file is a file "+f.isFile());
	System.out.println("The file is a directory "+f.isDirectory());
	}

}
