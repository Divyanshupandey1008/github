package org.FileHandling;
import java.io.*;

public class Bufferscanner_exp {
	public static void main(String[] args) throws Exception{
		
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));//THIS IS THE TEMPRORY OBJECT SIMILER SCAANER BUT SCAANNER IS NOT TEMPOPRY//
	System.out.println("Enter empno");
	int empno=Integer.parseInt(br.readLine());
	System.out.println("Enter empname");
	String name=br.readLine();
	System.out.println("Enter address");
	String address=br.readLine();
	System.out.println("Enter salary");
	float salary=Float.parseFloat(br.readLine());
	System.out.println("the empno is "+empno);
	System.out.println("the empname is "+name);
	System.out.println("the address is "+address);
	System.out.println("the salary is "+salary);
	
	
}}





