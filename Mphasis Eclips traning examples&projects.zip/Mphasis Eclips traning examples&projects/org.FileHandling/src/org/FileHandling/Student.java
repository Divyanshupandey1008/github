package org.FileHandling;
import java.io.*;

		public class Student implements Serializable
	{
	int rollno;
	String name,address;
	}
	
