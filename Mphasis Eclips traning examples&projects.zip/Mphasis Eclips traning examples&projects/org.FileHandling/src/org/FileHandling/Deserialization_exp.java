package org.FileHandling;
import java.io.*;
public class Deserialization_exp {
	public static void main(String[] args)throws Exception 
	{
		Student s1=null;
		FileInputStream fis=new FileInputStream("Object.txt");
		ObjectInputStream os=new ObjectInputStream(fis);
		s1=(Student) os.readObject();
		fis.close();os.close();
		System.out.println("The rollno is "+s1.rollno);
		System.out.println("The name is "+s1.name);
		System.out.println("The address is "+s1.address);

}
}