package org.FileHandling;
import java.io.*;

public class Fileinput_output_exp2 {
	public static void main(String[] args) {
	    try {
	        FileReader reader = new FileReader("Firstfilehandling.txt");
	        FileWriter writer = new FileWriter("Firstfilehandling2.txt");

	        int data;
	        int data2;
	        while((data=reader.read())!= -1) //-1 indicate the end of the file.
	        {
	          data2=Character.toUpperCase(data);
	          writer.write(data2);
	        }
	        reader.close();
	        writer.close();

	        
	    } 
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    
	  }
	}
	}


