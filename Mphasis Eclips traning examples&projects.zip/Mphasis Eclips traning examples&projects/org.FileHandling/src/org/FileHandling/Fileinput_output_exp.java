package org.FileHandling;

import java.io.*;

public class Fileinput_output_exp { // reading data from one file and writing data into another file.
	public static void main(String[] args) {
		
	}

	public class Fourth {
		public static void main(String[] args) throws Exception {
			FileInputStream fis = new FileInputStream("Firstfilehandling.txt");// read
			FileOutputStream fos = new FileOutputStream("Firstfilehandling2.txt");// writing
			int data;
			while ((data = fis.read()) != -1) {
				fos.write(data);
			}
			fis.close();
			fos.close();
			System.out.println("file copied..................");
		}
	}
}
