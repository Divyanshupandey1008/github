package org.relationship_assignment;

import java.util.*;

public class Customer {
	String cname, email, phoneno;

	void input() {
		Scanner ob = new Scanner(System.in);
		System.out.println("Enter Coustomer Name :");
		cname = ob.next();
		System.out.println("Enter Email ID :");
		email = ob.next();
		System.out.println("Enter Phone Number :");
		phoneno = ob.next();

	}

	void display() {
		System.out.println("Your name is :" + cname);
		System.out.println("Your emmailId is :" + email);
		System.out.println("Your phone number is :" + phoneno);

	}
}
