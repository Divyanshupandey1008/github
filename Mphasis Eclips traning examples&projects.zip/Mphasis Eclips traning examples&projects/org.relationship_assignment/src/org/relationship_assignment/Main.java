package org.relationship_assignment;

public class Main {
	public static void main(String[] args) {
		Product ob = new Product();
		ob.input();
		Customer ob1 = new Customer();
		ob1.input();
		Payment ob2 = new Payment();
		ob2.input();
		ob.display();
		ob1.display();
		ob2.display();

	}
}
