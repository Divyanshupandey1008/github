package org.relationship_assignment;

import java.util.*;

public class Payment {
	int accno, IFICIcode, amount;
	String yourname, bankname;

	void input() {
		Scanner ob = new Scanner(System.in);
		System.out.println("enter your Name :");
		yourname = ob.next();
		System.out.println("enter your Bank Name :");
		bankname = ob.next();
		System.out.println("enter your Account number :");
		accno = ob.nextInt();
		System.out.println("enter your IFICI Code :");
		IFICIcode = ob.nextInt();
		System.out.println("enter your Amount :");
		amount = ob.nextInt();

	}

	void display() {
		System.out.println("Your name is :" + yourname);
		System.out.println("Your bank name is :" + bankname);
		System.out.println("Your account number is :" + accno);
		System.out.println("Your IFICI code is :" + IFICIcode);
		System.out.println("Your Amount is :" + amount);
	}

}
