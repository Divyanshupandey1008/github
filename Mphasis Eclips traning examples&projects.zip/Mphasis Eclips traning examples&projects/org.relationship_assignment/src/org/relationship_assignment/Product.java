package org.relationship_assignment;

import java.util.Scanner;

public class Product {
	int pid, price;
	String pname;

	void input() {
		Scanner ob = new Scanner(System.in);

		System.out.println("Enter your PName");
		pname = ob.next();
		System.out.println("Enter your PID");
		pid = ob.nextInt();
		System.out.println("Enter Price");
		price = ob.nextInt();

	}

	void display() {
		System.out.println("Your product name is :" + pname);
		System.out.println("Your product Id is :" + pid);
		System.out.println("Your product price is :" + price);

	}

}
