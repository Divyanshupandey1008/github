package org.jdbc;
import java.sql.*;
import java.util.*;

public class Airlines_exp {
	public static void main(String[] args) throws Exception {
		try (Scanner ob = new Scanner(System.in)) {
			System.out.println("Enter your choice 1.create,2.insert,3.update,4.delete,5.select");
			int a = ob.nextInt();
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// create connection
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");

			// query statement
			Statement st = con.createStatement();
			switch (a) {

			case 1:
				st.execute(
						"create table Airlines(Flight_number number,Cname varchar2(30),Caddress varchar2(30),source varchar2(20),destination varchar2(20))");
				System.out.println("Table created");
				break;
			case 2:
				PreparedStatement st1 = con.prepareStatement("insert into Airlines values(?,?,?,?,?)");
				System.out.println("Enter Flight_number,Cname,Caddress,source,destination");
				int Flight_number = ob.nextInt();
				String Cname = ob.next();
				String Caddress = ob.next();
				String source = ob.next();
				String destination = ob.next();
				st1.setInt(1, Flight_number);
				st1.setString(2, Cname);
				st1.setString(3, Caddress);
				st1.setString(4, source);
				st1.setString(5, destination);
				st1.execute();
				System.out.println("row inserted");
				break;
			case 3:
				PreparedStatement st2 = con.prepareStatement("update Airlines set Cname=? where Flight_number=?");
				System.out.println("enter Flight_number and Cname to be updated");
				int Flight_number1 = ob.nextInt();
				int Cname1 = ob.nextInt();
				st2.setInt(1, Cname1);
				st2.setInt(2, Flight_number1);
				st2.execute();
				System.out.println("Name updated");
				break;
			case 4:
				PreparedStatement st3 = con.prepareStatement("delete from Airlines where Flight_number=?");
				System.out.println("enter Flight_number need to be deleted");
				int Flight_number2 = ob.nextInt();
				st3.setInt(1, Flight_number2);
				st3.execute();
				System.out.println("row deleted");
				System.out.println("account closed");
				break;
			case 5:// --------------ISSE HUM SEARCH KER SAKTE HAI DATA KO TABLE ME SE
					// --------------------------//
				PreparedStatement st4 = con.prepareStatement("select * from Airlines where Flight_number=?");
				System.out.println("Enter empno you want to search");
				int empno = ob.nextInt();
				st4.setInt(1, empno);
				ResultSet rs = st4.executeQuery();
				if (rs.next()) {
					System.out.println(rs.getInt(1) + "  " + rs.getString(2) + "  " + rs.getString(3));
				} else
					System.out.println("no record found....");

			}
		}
	}
}
