package org.jdbc;

import java.sql.*;

public class First_jdbc_Connectvity_EXP1 {
	public static void main(String[] args) throws Exception {

		// load the driver

		Class.forName("oracle.jdbc.driver.OracleDriver");
		// create connection
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "1234");
		// query statement
		Statement st = con.createStatement();
		st.execute("create table Mphasis(empno number,name varchar2(30),salary number)");//YE TABLE CREATE KERNE KA SYNTAX HAI

		System.out.println("table created");
		
		st.execute("insert into mphasisJdbc values(101,'Divyanshu',56000)");//YE TABLE ME DATA INSERT KERNE KA SYNTAX HAI
		st.execute("insert into mphasisJdbc values(102,'Mohit',16000)");
		st.execute("insert into mphasisJdbc values(103,'janu',60000)");
		st.execute("insert into mphasisJdbc values(104,'sonaa',76000)");
		System.out.println("Row inserted");

	}
}
