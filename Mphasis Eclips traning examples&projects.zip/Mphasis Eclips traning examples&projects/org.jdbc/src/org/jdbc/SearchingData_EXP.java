package org.jdbc;
import java.sql.*;
public class SearchingData_EXP {

	public static void main(String[] args)throws Exception 
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		PreparedStatement st=con.prepareStatement("select * from Airlines");
		ResultSet rs=st.executeQuery();
		while(rs.next())
		{
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));
	}
	}
	}

