package org.exceptionHandling;

import java.util.*;

public class ExceptionExp_Arraytype {
	public static void main(String[] args) {
		int a[] = new int[5];
		try {
			Scanner ob = new Scanner(System.in);
			System.out.println("Enter 5 nos");
			for (int i = 0; i < 5; i++)
				a[i] = ob.nextInt();

			System.out.println("The 5 nos are");
			for (int i = 0; i <= 5; i++)
				System.out.println(a[i]);
		} catch (Exception ae) {           //The catch block will execute when there is error.
			System.out.println("the error is " + ae);

		} finally {  //The finally block will execute if there is error or no error.//
			System.out.println("These are 5 nos");
		}
	}
}
