package org.exceptionHandling;

public class Exception_throws_Exp extends Thread  {
	
	public static void main(String[] args) throws InterruptedException 
	{
		for(int i=1;i<=10;i++)
		{
			System.out.println(i);
			sleep(1000);//has to be checked with handling error itt will not allow you to run 
	}
	}
}


