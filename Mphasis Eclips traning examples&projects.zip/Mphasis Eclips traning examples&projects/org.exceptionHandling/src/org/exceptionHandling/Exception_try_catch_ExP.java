package org.exceptionHandling;
import java.util.*;
public class Exception_try_catch_ExP 
{
public static void main(String[] args) 
{
	try{
	Scanner ob=new Scanner(System.in);
	System.out.println("enter two number");
	int a=ob.nextInt();
	int b=ob.nextInt();
	int c=a/b;
	System.out.println("The result is :"+c);
	}
	catch(Exception a) {
	System.out.println("the error is "+a);
	}
	System.out.println("the end");

}
}