package org.InterfaceExp;

interface a1 {
	void display();

}

interface a2 {
	void display1();
}

interface a3 extends a2 {
	void display2();
}

public class InterfaceDemo implements a1, a3 {

	@Override
	public void display1() {
		System.out.println("display1");
	}

	@Override
	public void display2() {
		System.out.println("display2");
	}

	@Override
	public void display() {

		System.out.println("display");
	}

	public static void main(String[] args) {
		InterfaceDemo ob = new InterfaceDemo();
		ob.display();
		ob.display1();
		ob.display2();

	}

}
	
