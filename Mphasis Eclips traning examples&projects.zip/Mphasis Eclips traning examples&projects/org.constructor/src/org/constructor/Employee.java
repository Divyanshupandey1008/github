package org.constructor;
import java.util.*;
public class Employee {
	int empno;
	String name,design,dept;
	float salary;
	Employee(int empno,String name,String design,String dept,float salary )
	{
		this.empno=empno;
		this.name=name;
		this.design=design;
		this.dept=dept;
		this.salary=salary;
	}
	void display()
	{
		System.out.println("the employee number is "+empno);
		System.out.println("the employee number is "+name);
		System.out.println("the employee number is "+design);
		System.out.println("the employee number is "+dept);
		System.out.println("the employee number is "+salary);
	}
public static void main(String[] args) {
	Employee ob=new Employee(101,"divyanshu","ASE","IT",20000.23F);
	ob.display();
}
}
