package org.InheritanceEXP;

public class Student {

}
