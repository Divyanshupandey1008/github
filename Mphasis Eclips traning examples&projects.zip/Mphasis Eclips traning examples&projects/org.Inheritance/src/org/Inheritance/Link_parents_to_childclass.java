
package org.inheritance;

public class Link_parents_to_childclass extends Student 
{
	int phy,chem,maths,total;

	public Link_parents_to_childclass (int rollno, String name, String address, int phy, int chem, int maths) {
		super(rollno, name, address);
		this.phy = phy;
		this.chem = chem;
		this.maths = maths;
	}
	void display()
	{
		super.display();
		System.out.println("the physics marks is "+phy );
		System.out.println("the chemistry marks is "+chem );
		System.out.println("the maths marks is "+maths );
		System.out.println("the total marks is "+(phy+chem+maths));
				}
public static void main(String[] args) {
	Link_parents_to_childclass  ob=new Link_parents_to_childclass (101,"sandip","bangalore",66,77,49);
	ob.display();
}
}