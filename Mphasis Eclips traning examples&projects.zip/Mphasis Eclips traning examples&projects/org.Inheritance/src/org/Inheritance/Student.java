package org.Inheritance;
import java.util.*;

public class Student {
	int Rollno;
	String name,address;
	public Student(int Rollno,String name,String address)
	{
		this.Rollno=Rollno;
		this.name=name;
		this.address=address;
	}
	void display()
	{
		System.out.println("ROLL NO IS :"+Rollno);
		System.out.println("NAME IS :"+name);
		System.out.println("Adress is :"+address);
	}
	public static void main(String[] args) {
		Student ob=new Student(101,"janu","deoria");
		ob.display();
	}

}
