package org.Inheritance;

public class Product {
	int Pid,price;
	String name;
	public Product(int Pid,int price,String name)
	{
		this.Pid=Pid;
		this.price=price;
		this.name=name;
    }
	void display()
	{
		System.out.println("product ID is :"+Pid);
		
		System.out.println("price is :"+price);
		
		System.out.println("product name is :"+name);
	}
}
