package org.Inheritance;

public class Custmore extends Product{
	String cus_name,address,emailId,phoneno;

	public Custmore(int Pid,int price,String name,String cus_name,String address,String emailId,String phoneno)
	{
		
super(Pid,price,name);
		
		this.cus_name=cus_name;
		this.address=address;
		this.emailId=emailId;
		this.phoneno=phoneno;
		}
	
	void display()
	{
		super.display();
		
		System.out.println("the Custmore name is "+cus_name );
		System.out.println("the Address is "+address );
		System.out.println("the Emailid is "+emailId );
		System.out.println("the phone number is "+phoneno);
		
}
	public static void main(String[] args) {
		
Custmore ob=new Custmore(101,1000,"Mobilephone","divyanshu","chennai","divyanshu1@gmail.com","9240977723");
		ob.display();
	
	}
}