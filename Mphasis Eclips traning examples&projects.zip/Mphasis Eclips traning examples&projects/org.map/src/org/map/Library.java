package org.map;

public class Library {
	int bookid,price;
	String bname,authorname;
	public Library(int bookid, int price, String bname, String authorname) {
		super();
		this.bookid = bookid;
		this.price = price;
		this.bname = bname;
		this.authorname = authorname;
	}
	@Override
	public String toString() {
		return "Library [bookid=" + bookid + ", price=" + price + ", bname=" + bname + ", authorname=" + authorname
				+ "]";
	}
	
		

	

}
