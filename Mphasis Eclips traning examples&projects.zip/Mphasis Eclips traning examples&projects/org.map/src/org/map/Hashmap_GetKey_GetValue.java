package org.map;
import java.util.*;
public class Hashmap_GetKey_GetValue {
public static void main(String[] args) {
	HashMap<Integer, String> hm=new HashMap<Integer, String>();
	hm.put(1, "sandip");
	hm.put(2, "sunil");
	hm.put(4, "sumeet");
	hm.put(3, "sakeet");
	hm.put(5, "anil");
	hm.put(7, "amit");
	hm.put(6, "arun");
	hm.put(6, "kiran");
	Scanner ob=new Scanner(System.in);
	System.out.println("Enter key and value");
	int x=ob.nextInt();
	String y=ob.next();
	hm.put(x, y);
	Set st=hm.entrySet();
	Iterator itr=st.iterator();
	while(itr.hasNext())
	{
	Map.Entry en=(Map.Entry)itr.next();
	System.out.println(en.getKey()+" ******* "+en.getValue());
	}
	}
}

