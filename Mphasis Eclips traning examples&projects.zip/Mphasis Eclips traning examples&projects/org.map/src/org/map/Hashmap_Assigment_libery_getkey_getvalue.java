package org.map;

import java.util.*;

public class Hashmap_Assigment_libery_getkey_getvalue {
	public static void main(String[] args) {
		HashMap <Integer, Library> hm = new HashMap<Integer, Library>();
		Library lb1 = new Library(121,2000, "Rich Dad Poor dad","Nepolian hill");
		Library lb2 = new Library(122,1000, "As a Men Thinketh","James Allin");
		Library lb3 = new Library(123,2500, "Think and Grow rich","Nepolian hill");
		Library lb4 = new Library(124,1800, "Tao Te Ching","Lao Tzu");
		hm.put(1, lb1);
		hm.put(2, lb2);
		hm.put(3, lb3);
		hm.put(4, lb4);
		Scanner ob = new Scanner(System.in);
		System.out.println("Enter the slno you want to search");
		Integer slno = ob.nextInt();
		Set st = hm.entrySet();
		Iterator itr = st.iterator();
		while (itr.hasNext()) {
			Map.Entry en = (Map.Entry) itr.next();
			if (en.getKey() == slno)
				System.out.println(en.getKey() + " ******* " + en.getValue());

		}
	}
}
