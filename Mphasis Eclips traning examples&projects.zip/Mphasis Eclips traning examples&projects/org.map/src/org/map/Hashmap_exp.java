package org.map;
import java.util.*;

public class Hashmap_exp {
	
	public static void main(String[] args) {
		HashMap hm= new HashMap();
		hm.put(1,"Divyanshu");
		hm.put(2,"avnnesh");
		hm.put(3,"nishant");
		hm.put(4,"pradeeep");
		hm.put(7, "amit");
		hm.put(6, "arun");
		hm.put(6, "kiran");
		hm.put(5,"anshul");
		System.out.println(hm);
		
	}

}
