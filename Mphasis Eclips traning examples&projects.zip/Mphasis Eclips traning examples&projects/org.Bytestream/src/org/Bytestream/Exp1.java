package org.Bytestream;

import java.io.*;
import java.util.*;

public class Exp1 {
	public static void main(String[] args) throws Exception 
		{

		DataInputStream dis = new DataInputStream(System.in);
		FileOutputStream fis = new FileOutputStream("student.txt");
		System.out.println("Enter the data");
		int data;
		while ((data = dis.read()) != '\n') 
		{
			fis.write(data);
		}
		System.out.println("Witting over");
		dis.close();
		fis.close();
	}

}