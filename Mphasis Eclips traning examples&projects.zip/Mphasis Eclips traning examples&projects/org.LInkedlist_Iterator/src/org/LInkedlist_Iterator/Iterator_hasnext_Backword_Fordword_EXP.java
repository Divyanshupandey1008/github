package org.LInkedlist_Iterator;
import java.util.*;
public class Iterator_hasnext_Backword_Fordword_EXP {
	public static void main(String[] args) {
		LinkedList<Integer> ls1=new LinkedList<Integer>();
		ls1.add(50);
		ls1.add(60);
		ls1.add(40);
		ls1.add(30);
		ls1.add(20);
		ls1.add(10);
		ListIterator itr=ls1.listIterator();
		System.out.println("Forward Direction");
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		System.out.println("Backward Direction");
		while(itr.hasPrevious())
		{
			System.out.println(itr.previous());
		}
		
		}

	

}
