package org.LInkedlist_Iterator;

import java.util.*;

public class Iterator_hasnext_EXP {
	public static void main(String[] args) {
		LinkedList<Integer> ls1 = new LinkedList<Integer>();
		ls1.add(50);
		ls1.add(60);
		ls1.add(40);
		ls1.add(30);
		ls1.add(20);
		ls1.add(10);
		Iterator itr = ls1.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
	}

}
