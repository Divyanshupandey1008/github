import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import javax.servlet.annotation.*;
@WebServlet("/SecondServlet")



public class SecondServlet extends HttpServlet
{
public void doGet(HttpServletRequest req,HttpServletResponse res)
{
try
{
res.setContentType("text/html");
PrintWriter pw=res.getWriter();
String c=req.getParameter("t3");
String d=req.getParameter("t4");
HttpSession ses=req.getSession(false);
ses.setAttribute("g",c);
ses.setAttribute("h",d);
String a=(String)ses.getAttribute("x");
String b=(String)ses.getAttribute("y");

pw.println("the rollno is :"+a);
pw.println("the name is :"+b);
pw.println("the address is :"+c);
pw.println("the phone no is :"+d);
}
catch(Exception ae)
{}
}
}