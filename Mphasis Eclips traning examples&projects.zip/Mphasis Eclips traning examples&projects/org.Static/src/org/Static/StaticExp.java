package org.Static;

public class StaticExp {
	static int a=50,b=60;
	
	static void display() {
		System.out.println("this is static method example ");
	}
	static
	{
		System.out.println("this is static block");
		
	}
	public static void main(String[] args) {
		display();
		System.out.println("The value of a is "+a);
		System.out.println("The value of b is "+b);
	}

}
