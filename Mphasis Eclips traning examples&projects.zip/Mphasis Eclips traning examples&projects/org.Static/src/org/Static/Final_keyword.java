package org.Static;


final class Final_keyword //final class cannot be extended
{
final int a = 10; //final variable has to be assigned and cannot be changed
final void display()//final method cannot be overriden
{
	System.out.println("the value of a is "+a);
	System.out.println("This is a final method");
}
public static void main(String[] args) 
{
	 Final_keyword ob=new  Final_keyword();
ob.display();
}

}