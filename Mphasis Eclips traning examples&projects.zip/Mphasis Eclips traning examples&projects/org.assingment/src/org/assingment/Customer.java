package org.assingment;

import java.util.*;

public class Customer {

	void input() {
		Scanner ob = new Scanner(System.in);
		System.out.println("Enter Your Name :");
		String cname = ob.next();
		System.out.println("Enter your Address :");
		String address = ob.next();
		System.out.println("Enter your email");
		String email = ob.next();
		System.out.println("Enter your phone no");
		String phoneno = ob.next();
	}

	void ICIC() {
		String Accno = "00123837";
		String loc = "chandigrah";
		int balance = 100000;
		System.out.println("Your account number is :" + Accno);
		System.out.println("your bank loction is :" + loc);
		System.out.println("your bank balance is :" + balance);

	}

	void SBI() {
		String Accno = "81123837";
		String loc = "Mumbai";
		int balance = 400000;
		System.out.println("Your account number is :" + Accno);
		System.out.println("your bank loction is :" + loc);
		System.out.println("your bank balance is :" + balance);

	}

	public static void main(String[] args) {
		Scanner ob = new Scanner(System.in);
		Customer ob1 = new Customer();
		ob1.input();
		System.out.println("Select your bank 1.ICIC 2.SBI");
		int x = ob.nextInt();
		if (x == 1) {
			ob1.ICIC();
		} else {
			ob1.SBI();
		}

	}

}
