package org.assingment;
import java.util.*;
public class Bank {
	int ACno,balance; 
	String name;
	
	void input() 
	{
		Scanner ob=new Scanner(System.in);
		System.out.println("Enter ACCOUNT NUMBER :");
		ACno=ob.nextInt();
		System.out.println("Enter YOUR NAME :");
		name=ob.next();
		System.out.println("Enter YOUR BALANCE :");
		balance=ob.nextInt();
	}
	void withdraw() 
	{
		Scanner ob=new Scanner(System.in);
		System.out.println("How much money you want to withdraw :");
		int m=ob.nextInt();
		if(balance>m) {
			System.out.println("withdrwa sucessfull...and your account blance is  :"+(balance-m));
		}
		else {
			System.out.println("sorrryyyy....balance is not enough to withdraw");
		}
	}
	void deposit() 
	{
	Scanner ob=new Scanner(System.in);
	System.out.println("How much money you want to Deposit :");
	int n=ob.nextInt();
	System.out.println("your balance after adding deposit amount"+(balance+n));
	}
	public static void main(String[] args) {
		Scanner ob=new Scanner(System.in);
		System.out.println("choose your choice 1.withdraw 2.deposit");
		int x=ob.nextInt();
		if(x==1) {
			Bank ob1=new Bank();
			ob1.input();
			ob1.withdraw();
		}
		else
		{
          Bank ob1=new Bank();
			ob1.input();
			ob1.deposit();
		}
		
	}
	
	}
	

