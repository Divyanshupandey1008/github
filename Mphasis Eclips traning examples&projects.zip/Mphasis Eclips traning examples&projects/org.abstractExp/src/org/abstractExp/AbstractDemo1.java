package org.abstractExp;

public class AbstractDemo1 {

}
