package org.collectionFramework;
import java.util.*;

public class LinkdList {

public static void main(String[] args) {
		LinkedList<String> ts=new LinkedList<String>();
		ts.add("Ball");
		ts.add("Bat");
		ts.add("Apple");
		ts.add("Amit");
		ts.add("Grapes");
		ts.add("Orange");
		ts.add(3,"Banana");//insert into the 3rd index
		ts.remove(2);//remove 2nd index
		ts.set(3,"Mango");//replace the 3rd index
		System.out.println(ts);

	}
	}

