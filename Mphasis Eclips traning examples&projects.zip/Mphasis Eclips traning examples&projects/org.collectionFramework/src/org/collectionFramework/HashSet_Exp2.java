package org.collectionFramework;
import java.util.*;
public class HashSet_Exp2 {
	public static void main(String[] args) {
		HashSet<Integer> ts=new HashSet<Integer>();
		ts.add(60);
		ts.add(50);
		ts.add(40);
		ts.add(20);
		ts.add(30);
		ts.add(10);
		ts.add(70);
		ts.add(80);
		ts.add(80);
			System.out.println(ts);
			System.out.println("*********************************");
			for(Object ob:ts)
				System.out.println(ob);

}
}
