package org.collectionFramework;
import java.util.*;

public class TreeSet_EXP {
	public static void main(String[] args) {
		TreeSet<Integer> ts=new TreeSet<Integer>();      //TREESET use to display the record in Orderwise and also remove the duplication//
		ts.add(110);
		ts.add(90);
		ts.add(100);
		ts.add(60);
		ts.add(70);
		ts.add(50);
		ts.add(80);
		System.out.println(ts);
		
		
	}
}
