package org.collectionFramework;

import java.util.*;

public class Exp_Linkedhashset {

public static void main(String[] args) {
	


		LinkedHashSet<Employee> ts = new LinkedHashSet<Employee>();

		Employee ob = new Employee(101, 1000,"Divyanshu", "SE");
		Employee ob1 = new Employee(102, 1000,"Prakash", "SE");
		Employee ob2 = new Employee(103, 1000,"Prakash", "SE");

		ts.add(ob);
		ts.add(ob1);
		ts.add(ob2);
		for (Object obj : ts)
			System.out.println(obj);

		
	}
}