package org.collectionFramework;

public class Employee {

	int empno, salary;
	String name, designation;

	public static void main(String[] args) {
	
	}
	public Employee(int empno, int salary, String name, String designation) {
		super();
		this.empno = empno;
		this.salary = salary;
		this.name = name;
		this.designation = designation;
	}

	@Override
	public String toString() {
		return "Employee [empno=" + empno + ", salary=" + salary + ", name=" + name + ", designation=" + designation
				+ "]";
	}

}
