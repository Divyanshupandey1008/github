package org.collectionFramework;
import java.util.*;

public class HashSet_Exp {
		public static void main(String[] args) {
			HashSet<String> ts=new HashSet<String>();
			ts.add("Ball");
			ts.add("Bat");
			ts.add("Apple");
			ts.add("Amit");
			ts.add("Grapes");
			ts.add("Orange");
			System.out.println(ts);

		}
		}


