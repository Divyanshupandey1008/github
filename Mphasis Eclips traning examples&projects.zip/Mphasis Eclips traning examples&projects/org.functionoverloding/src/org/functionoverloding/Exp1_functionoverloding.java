package org.functionoverloding;

public class Exp1_functionoverloding {
	
	int sum(int a,int b)
	{
	return a+b;	
	}
	float sum(float a,float b)
	{
		return a+b;
	}
	double sum(double a,double b)
	{
		return a+b;
	}
public static void main(String[] args) {
	 Exp1_functionoverloding ob1=new  Exp1_functionoverloding ();
	 System.out.println("The sum is "+ob1.sum(56.33, 53.22));
		System.out.println("The sum is "+ob1.sum(4,5));
		System.out.println("The sum is "+ob1.sum(51.33f, 53.22f));
		System.out.println("The sum is "+ob1.sum(14,15));
		System.out.println("The sum is "+ob1.sum(21.33f, 33.22f));
	
}

}
