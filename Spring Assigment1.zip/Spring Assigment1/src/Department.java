public class Department {
	private String deptname;
	private String Location;
	private String designation;

	public Department(String deptname, String location, String designation) {
		super();
		this.deptname = deptname;
		Location = location;
		this.designation = designation;
	}

	void display() {
		System.out.println(deptname + "\n" + Location +"\n"+designation );
	}
}