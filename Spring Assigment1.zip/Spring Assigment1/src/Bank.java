public class Bank {  
private String accno;  
private String branch; 
private String balance;  

  


public Bank(String accno, String branch, String balance) {
	super();
	this.accno = accno;
	this.branch = branch;
	this.balance = balance;
}




void display(){  
    System.out.println(accno+" \n"+branch+" \n"+balance);  
}}  