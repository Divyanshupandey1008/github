import org.springframework.beans.factory.BeanFactory;  
import org.springframework.beans.factory.xml.XmlBeanFactory;  
import org.springframework.core.io.*;  
  
public class Test {  
    public static void main(String[] args) {  
          
        Resource e=new ClassPathResource("applicationContext.xml");  
        BeanFactory factory=new XmlBeanFactory(e); 
   
        
        
        Customer a=(Customer)factory.getBean("e");  
        Bank b=(Bank)factory.getBean("f");  
       Department c=(Department)factory.getBean("g"); 
       System.out.println("--------------------------------------------------------------");
       System.out.println("Customer Detail");
       System.out.println("--------------------------------------------------------------");
      a.display(); 
      System.out.println("--------------------------------------------------------------");
        System.out.println("Bank Detail");
        System.out.println("--------------------------------------------------------------");
        b.display(); 
        System.out.println("--------------------------------------------------------------");
        System.out.println("Department Detail ");
        System.out.println("--------------------------------------------------------------");
         c.display(); 
        
         System.out.println("--------------------------------------------------------------");
          
    }  
}  