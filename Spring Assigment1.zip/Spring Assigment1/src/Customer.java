public class Customer {  
private int id;  
private String name; 
private String bank;  
private String dept;  
  

public Customer(int id, String name, String bank, String dept) {
	super();
	this.id = id;
	this.name = name;
	this.bank = bank;
	this.dept = dept;
}

void display(){  
    System.out.println(id+"\n"+name+"\n"+bank+"\n"+dept);  
}}  