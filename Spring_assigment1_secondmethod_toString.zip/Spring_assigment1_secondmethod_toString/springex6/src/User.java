public class User {  
 
private String name;
private String location;
private String desig;
public User() {}  
public User(String name, String location, String desig) {  
    super();  
   
    this.name = name;  
    this.location = location;  
    this.desig=desig;
}  
  
public String toString(){  
    return "\nName:"+name+"\nlocation:"+location+"\nDesignation:"+desig;  
}  
}  